/**
 * processingrocket
 * Library for fast prototyping of micro-controllers through serial protocols
 * http://rocketuc.com
 *
 * Copyright (C) 2012 Stefan Wendler http://gpio.kaltpost.de
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Stefan Wendler http://gpio.kaltpost.de
 * @modified    05/12/2012
 * @version     0.1.1 (1)
 */

package rocketuc.processing;


import processing.core.*;
import rocketuc.jrocket.JRocket;
import rocketuc.jrocket.JRocketSerial;
import rocketuc.jrocket.comm.Packet;

/**
 * This is a template class and can be used to start a new processing library or tool.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own library or tool naming convention.
 * 
 * @example Hello 
 * 
 * (the tag @example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 */

public class ROCKETuC extends JRocketSerial {
	
	// myParent is a reference to the parent sketch
	PApplet myParent;
	
	public final static String VERSION = "0.1.1";
	

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the library.
	 * 
	 * @example Hello
	 * @param theParent
	 */
	public ROCKETuC(PApplet theParent, String port) throws Exception {
		myParent = theParent;
		init(port);
	}
	
	@Override
	public void handleEvent(Packet pkt) {
		externalInterrupt(pkt.getData()[0]);
	}

	public void externalInterrupt(short pin) {		
	}
	
	/**
	 * return the version of the library.
	 * 
	 * @return String
	 */
	public static String version() {
		return VERSION;
	}
}

